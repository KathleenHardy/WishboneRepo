		<!-- footer -->
		<footer class="footer">
			<div class="footer__copyright">
			<div class="row">
			<div class="col-md-4"><a style="color: #f39c12; font-size: 20px; font-family:'Archivo', sans-serif; font-weight: 700;"
								href="index.php">WISHBONE</a></div>
			<div class="col-md-4" style="font-family:'Archivo', sans-serif; font-size: 10px; color: white;">2020 &copy; Copyright Wishbone.
				All rights Reserved.</div>
			<div class="col-md-4" style="font-family:'Archivo', sans-serif; color: #f39c12;"><a href="#" id="back-to-top"> <i class="fa fa-angle-up"
								aria-hidden="true"> </i><span>BACK TO TOP</span></a></div>
			</div>
		</div>
		</footer>
		<!-- End / footer -->