<?php
class UserType { 
    const EVENT_PLANNER = 1;
    const ENTERTAINER = 2;
    const VENUE_OWNER = 3;
}
?>