
    <!-- JAVASCRIPTS (Load javascripts at bottom, this will reduce page load time) -->
    <!-- Global Vendor -->
    <script src="../assets/vendors/jquery.min.js"></script>
    <script src="../assets/vendors/jquery.migrate.min.js"></script>
    <script src="../assets/vendors/popper.min.js"></script>
    <script src="../assets/vendors/bootstrap/js/bootstrap.min.js"></script>

    <!-- Components Vendor  -->
    <script src="../assets/vendors/jquery.parallax.js"></script>
    <script src="../assets/vendors/magnific-popup/jquery.magnific-popup.min.js"></script>
    <script src="../assets/vendors/shuffle/jquery.shuffle.min.js"></script>

    <!-- Theme Settings and Calls -->
    <script src="../assets/js/global.js"></script>

    <!-- Theme Components and Settings -->
    <script src="../assets/js/vendors/parallax.js"></script>
    <script src="../assets/js/vendors/magnific-popup.js"></script>
    <script src="../assets/js/vendors/shuffle.js"></script>
    <!-- END JAVASCRIPTS -->